<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\EmployeeController;

Route::get('/', function () {
    return view('welcome');
});
Route::get('add-employee',[EmployeeController::class, 'addEmployee']);
Route::post('save-employee',[EmployeeController::class, 'saveEmployee']);
Route::get('employee-list',[EmployeeController::class, 'index']);
Route::get('edit-employee/{id}',[EmployeeController::class, 'editEmployee']);
Route::post('update-employee',[EmployeeController::class, 'updateEmployee']);

