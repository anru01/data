<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Employee</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
</head>
<body>
    <div class="container">
        <div class="row">
        <div class="col-md-8 offset-2">
        <h2>Add Employee</h2>
        @if (Session::has('success'))
        <div class="alert alert-danger">{{ Session::get('success') }}</div>
        @endif
        <form method="post" action="{{ url('save-employee')}}">
            @csrf
            <div class="md-3">
                <label>First Name</label>
                <input type="text" name="firstname" class="form-control" placeholder="Enter your First Name"/>
                @error('firstname')
                <div class="alert alert-danger">{{ $message }}</div>
                @enderror

</div>
<div class="md-3">
                <label>Last Name</label>
                <input type="text" name="lastname" class="form-control" placeholder="Enter your Last Name"/>
                @error('lastname')
                <div class="alert alert-danger">{{ $message }}</div>
                @enderror
                
</div>
<div class="md-3">
                <label>Email</label>
                <input type="text" name="email" class="form-control" placeholder="Enter your Email"/>
                @error('email')
                <div class="alert alert-danger">{{ $message }}</div>
                @enderror
                
</div>
<div class="md-3">
                <label>Password</label>
                <input type="password" name="password" class="form-control" placeholder="Enter yourPassword"/>
                @error('password')
                <div class="alert alert-danger">{{ $message }}</div>
                @enderror
                
</div>
<div class="md-3">
                <label>Mobile</label>
                <input type="text" name="mobile" class="form-control" placeholder="Enter your Mobile" maxlength="10"/>
                @error('mobile')
                <div class="alert alert-danger">{{ $message }}</div>
                @enderror
                
</div>
<div class="md-3">
                <label>Address</label>
                <input type="text" name="address" class="form-control" placeholder="Enter your Address"/>
                @error('address')
                <div class="alert alert-danger">{{ $message }}</div>
                @enderror
                
</div>
<div class="md-3">
                <label>First Name</label>
                <input type="submit" name="submit" class="btn btn-success" value="Submit"/>
                @error('submit')
                <div class="alert alert-danger">{{ $message }}</div>
                @enderror
                
</div>
</form>
</div>
</div>
</div>
</body>
</html>