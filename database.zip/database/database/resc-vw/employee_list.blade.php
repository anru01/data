<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> Employee List</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
</head>
<body>
    <div class="container">
        <div class="row">
        <div class="col-md-12 offset-2">
        <h2> Employee List</h2>
        <div> <a href="{{ url('add-employee') }}">Add Employee</a></div>
        @if (Session::has('success'))
        <div class="alert alert-danger">{{ Session::get('success') }}</div>
        @endif
<table class="table">
    <thead>
        <th>#</th>
        <th>id</th>
        <th>First Name</th>
        <th>Last Name</th>
        <th>Email</th>
        <th>Password</th>
        <th>Mobile</th>
        <th>Address</th>
        <th>Action</th>
</thead>
<tbody>
    @php
            $i=1;
    @endphp
    @foreach ($data as $employee)
    <tr>
        <td>{{ $i++-> }}</td>
        <td>{{ $employee->id }}</td>
        <td>{{ $employee->first_name }}</td>
        <td>{{ $employee->last_name }}</td>
        <td>{{ $employee->email }}</td>
        <td>{{ $employee->password }}</td>
        <td>{{ $employee->mobile }}</td>
        <td>{{ $employee->address }}</td>
        <td>
            <a href="{{ url('edit-employee/'.$employee->id)}}">Edit</a> &nbsp;| &nbsp;
            <a href="{{ url('delete-employee/'.$employee->id)}}" class="btn btn-danger">Delete</a>
</tr>
@endforeach
</tbody>
</table>
</div>
</div>
</div>
</body>
</html>