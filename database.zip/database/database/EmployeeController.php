<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Employee;

class EmployeeController extends Controller
{
    public function index()
    {
        $data = Employee::get();
        return view('employee_list',compact('data'));
    }
    public function addEmployee()
    {
        return view('add_employee');
    }
    public function saveEmployee(Request $reQuest)
    {
        //dd($request->all());
        $request->validate([
            'firstname' =>'requird',
            'lastname' =>'requird',
            'email' =>'requird',
            'password' =>'requird',
            'mobile' =>'requird',
            'address' =>'requird',
        ]);
        $employee = new Employee(); 
        $employee->first_name = $request->firstname;
        $employee->last_name = $request->lastname;
        $employee->email = $request->email;
        $employee->password = $request->password;
        $employee->mobile = $request->mobile;
        $employee->address = $request->address;
        $employee->save();
        return redirect()->back()->with('success','Employee added successfully.');
    }
    public function editEmployee($id)
    {
        $data = Employee::where('id','=',$id)->first();
        return view('edit_employee',compact('data'));
    }
    public function updateEmployee(Request $request)
    {
        $request->validate([
            'firstname' =>'requird',
            'lastname' =>'requird',
            'email' =>'requird',
            'password' =>'requird',
            'mobile' =>'requird',
            'address' =>'requird',
        ]);
        Employee::where('id','=',$request->id)->update([
            'first_name' =>$request->firstname,
            'last_name' =>$request->lastname,
            'email' =>$request->email,
            'password' =>$request->password,
            'mobile' =>$request->mobile,
            'address' =>$request->address,
        ]);
        return redirect()->back()->with('success','Employee updated successfully.');
    }
}
