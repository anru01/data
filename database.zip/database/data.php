//php 

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Register</title>
    <script src="validate.js"></script>
</head>
<body>
    <form action="register.php" method="POST" onsubmit="return validateForm()">
        <div>
            <label for="id">ID:</label>
            <input type="text" id="id" name="id">
            <span id="idError" class="error"></span>
        </div>
        <div>
            <label for="firstname">First Name:</label>
            <input type="text" id="firstname" name="firstname">
            <span id="firstnameError" class="error"></span>
        </div>
        <div>
            <label for="lastname">Last Name:</label>
            <input type="text" id="lastname" name="lastname">
            <span id="lastnameError" class="error"></span>
        </div>
        <div>
            <label for="email">Email:</label>
            <input type="email" id="email" name="email">
            <span id="emailError" class="error"></span>
        </div>
        <div>
            <label for="password">Password:</label>
            <input type="password" id="password" name="password">
            <span id="passwordError" class="error"></span>
        </div>
        <div>
            <label for="confirm_password">Confirm Password:</label>
            <input type="password" id="confirm_password" name="confirm_password">
            <span id="confirmPasswordError" class="error"></span>
        </div>
        <div>
            <input type="submit" value="Register">
        </div>
    </form>
</body>
</html>

function validateForm() {
    var isValid = true;

    // Reset error messages
    document.getElementById('idError').innerText = '';
    document.getElementById('firstnameError').innerText = '';
    document.getElementById('lastnameError').innerText = '';
    document.getElementById('emailError').innerText = '';
    document.getElementById('passwordError').innerText = '';
    document.getElementById('confirmPasswordError').innerText = '';

    // Get form values
    var id = document.getElementById('id').value;
    var firstname = document.getElementById('firstname').value;
    var lastname = document.getElementById('lastname').value;
    var email = document.getElementById('email').value;
    var password = document.getElementById('password').value;
    var confirmPassword = document.getElementById('confirm_password').value;

    // Validate fields
    if (id === '') {
        document.getElementById('idError').innerText = 'ID cannot be empty';
        isValid = false;
    }
    if (firstname === '') {
        document.getElementById('firstnameError').innerText = 'First Name cannot be empty';
        isValid = false;
    }
    if (lastname === '') {
        document.getElementById('lastnameError').innerText = 'Last Name cannot be empty';
        isValid = false;
    }
    if (email === '') {
        document.getElementById('emailError').innerText = 'Email cannot be empty';
        isValid = false;
    }
    if (password === '') {
        document.getElementById('passwordError').innerText = 'Password cannot be empty';
        isValid = false;
    }
    if (confirmPassword === '') {
        document.getElementById('confirmPasswordError').innerText = 'Confirm Password cannot be empty';
        isValid = false;
    }
    if (password !== confirmPassword) {
        document.getElementById('confirmPasswordError').innerText = 'Passwords do not match';
        isValid = false;
    }

    return isValid;
}

<?php
$servername = "localhost";
$username = "your_username";
$password = "your_password";
$dbname = "your_database";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>

<?php
include 'connection.php';

$id = $_POST['id'];
$firstname = $_POST['firstname'];
$lastname = $_POST['lastname'];
$email = $_POST['email'];
$password = $_POST['password'];
$confirmPassword = $_POST['confirm_password'];

// Validate inputs
if (empty($id) || empty($firstname) || empty($lastname) || empty($email) || empty($password) || empty($confirmPassword)) {
    die("All fields are required.");
}

if ($password !== $confirmPassword) {
    die("Passwords do not match.");
}

// Prepare and bind
$stmt = $conn->prepare("INSERT INTO users (id, firstname, lastname, email, password) VALUES (?, ?, ?, ?, ?)");
$stmt->bind_param("sssss", $id, $firstname, $lastname, $email, password_hash($password, PASSWORD_DEFAULT));

// Execute the statement
if ($stmt->execute()) {
    echo "Registration successful!";
} else {
    echo "Error: " . $stmt->error;
}

$stmt->close();
$conn->close();
?>

//Laravel

layout.blade.php

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>@yield('title','FoodMan:Layout')</title>
</head>
<body>
    <button><a href="{{url('login')}}">Login</a></button>
    <button><a href="{{url('/')}}">Register</a></button>
    <button><a href="{{url('food')}}">Food</a></button>
    <button><a href="{{url('dess')}}">Dessert</a></button>

    @yield('content')


    <Footer>
        <p>This is the footer of this Food Management website</p>
    </Footer>
</body>
</html>

//register.blade.php
@extends('layout')
@section('title','FoodMan:Register')
@section('content')
<h1>Register</h1>
<form action="{{url('registerPost')}}" method="POST">
    @csrf
    <input type="text" name="name" placeholder="Enter Your name"><br><br>
    <input type="text" name="email" placeholder="Enter Your email"><br><br>
    <input type="text" name="phone_no" placeholder="Enter Your mobile"><br><br>
    <input type="password" name="password" placeholder="Enter Your password"><br><br>
    <input type="submit" value="Submit">
</form>
@endsection


//web.php

<?php

use App\Http\Controllers\DessrtController;
use App\Http\Controllers\FoodController;
use App\Http\Controllers\UserController;
use Illuminate\Support\Facades\Route;

// Route::view('/','layout');

Route::get('/',[UserController::class,'registerView'])->name('register');
Route::get('/login',[UserController::class,'loginView'])->name('login');


//create user registration route
Route::post('registerPost',[UserController::class,'insert']);

Route::post('loginPost',[UserController::class,'signin']);

Route::middleware('auth')->group(function() {

    //route of food page view
    Route::get('/food',[FoodController::class,'foodView'])->name('foodDashboard');
    Route::get('/dess',[DessrtController::class,'dessrtView'])->name('dessrtDashboard');

    Route::post('foodPost',[FoodController::class,'insert']);
    Route::get('deleteFood-{id}',[FoodController::class,'delete'])->name('deleteFood');
});

//usercontroller.php

<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class UserController extends Controller
{
    public function registerView(){
        return view('register');
    }

    public function loginView(){
        return view('login');
    }

    //to use store user details
    public function insert(Request $request)
    {
        //validation
        $request->validate([
            'name' => 'min:4|max:12',
            'email' => 'email|unique:users',
            'password' => 'min:4'
        ]);
        // dd($request);
        $user = User::create([
            'name' => $request->name,
            'email' => $request->email,
            'phone_no' => $request->phone_no,
            'password' => $request->password
        ]);

        if($user)
        {
            return redirect(route('login'));
        }else{
            return redirect()->back();
        }
    }

    public function signin(Request $request){
        $credentials = $request->only('email','password');

        if(Auth::attempt($credentials))
        {
            $request->session()->regenerate();
            return redirect(route('foodDashboard'));
        }else{
            return redirect()->back();
        }

    }
}
//food controller
<?php

namespace App\Http\Controllers;

use App\Models\Food;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class FoodController extends Controller
{
    //create food view function for show food page
    public function foodView(){
        $foods = Food::get()->all();
        // dd($foods);
        return view('food',compact('foods'));
    }

    public function insert(Request $request)
    {
        $request->validate([
            'name' => 'min:4',
            'price' => 'min:2',
            'count' => 'min:1',
        ]);

        $user = Auth::user();

        $food = Food::create([
            'userid' => $user->id,
            'name' => $request->name,
            'price' => $request->price,
            'count' =>$request->count,
            'category' => $request->category,
            'addons' => $request->addons
        ]);

        if($food){
            return redirect(route('foodDashboard'));
        }else{
            return redirect()->back();
        }
    }

    public function delete($id){
        $food = Food::find($id);
        if(Food::delete())
        {
            return redirect(route('foodDashboard'));
        }else{
            return redirect()->back();
        }
    }

    
}


//Create the React Project:
npx create-react-app staff-management-frontend
cd staff-management-frontend
npm install react-router-dom


//src/App.js
import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import LandingPage from './components/LandingPage';
import LoginPage from './components/LoginPage';
import RegisterPage from './components/RegisterPage';
import StaffListPage from './components/StaffListPage';
import StaffDetailPage from './components/StaffDetailPage';

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<LandingPage />} />
        <Route path="/login" element={<LoginPage />} />
        <Route path="/register" element={<RegisterPage />} />
        <Route path="/staff-list" element={<StaffListPage />} />
        <Route path="/staff/:id" element={<StaffDetailPage />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;


//src/components/LandingPage.js
import React from 'react';

const LandingPage = () => {
  return (
    <div>
      <h1>Welcome to the Staff Management System</h1>
      <p>Manage and view staff details easily.</p>
      <button onClick={() => window.location.href = "/login"}>Login</button>
      <button onClick={() => window.location.href = "/register"}>Sign Up</button>
    </div>
  );
};

export default LandingPage;



//src/components/LoginPage.js
import React, { useState } from 'react';

const LoginPage = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!email || !password) {
      alert('Please fill out all fields');
      return;
    }
    console.log('Email:', email);
    console.log('Password:', password);
    // Handle login logic here (e.g., API call for authentication)
  };

  return (
    <form onSubmit={handleSubmit}>
      <div>
        <label htmlFor="email">Email:</label>
        <input
          type="email"
          id="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
        />
      </div>
      <div>
        <label htmlFor="password">Password:</label>
        <input
          type="password"
          id="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          required
        />
      </div>
      <button type="submit">Login</button>
    </form>
  );
};

export default LoginPage;



//src/components/RegisterPage.js
import React, { useState } from 'react';

const RegisterPage = () => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [role, setRole] = useState('');
  const [password, setPassword] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!name || !email || !role || !password) {
      alert('Please fill out all fields');
      return;
    }
    console.log('Registration data:', { name, email, role, password });
    // Handle form submission (e.g., send data to your backend)
  };

  return (
    <form onSubmit={handleSubmit}>
      <div>
        <label htmlFor="name">Name:</label>
        <input
          type="text"
          id="name"
          value={name}
          onChange={(e) => setName(e.target.value)}
          required
        />
      </div>
      <div>
        <label htmlFor="email">Email:</label>
        <input
          type="email"
          id="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
        />
      </div>
      <div>
        <label htmlFor="role">Role:</label>
        <input
          type="text"
          id="role"
          value={role}
          onChange={(e) => setRole(e.target.value)}
          required
        />
      </div>
      <div>
        <label htmlFor="password">Password:</label>
        <input
          type="password"
          id="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          required
        />
      </div>
      <button type="submit">Register</button>
    </form>
  );
};

export default RegisterPage;


//src/components/StaffListPage.js
import React, { useState, useEffect } from 'react';

const StaffListPage = () => {
  const [staff, setStaff] = useState([]);

  useEffect(() => {
    // Replace with your API endpoint to fetch staff data
    fetch('/api/staff')
      .then((response) => response.json())
      .then((data) => setStaff(data))
      .catch((error) => console.error('Error fetching staff:', error));
  }, []);

  return (
    <div>
      <h2>Staff List</h2>
      <ul>
        {staff.map((staffMember) => (
          <li key={staffMember.id}>
            <a href={`/staff/${staffMember.id}`}>{staffMember.name} ({staffMember.role})</a>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default StaffListPage;


//src/components/StaffDetailPage.js

import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';

const StaffDetailPage = () => {
  const { id } = useParams();
  const [staffMember, setStaffMember] = useState(null);

  useEffect(() => {
    // Replace with your API endpoint to fetch staff data by ID
    fetch(`/api/staff/${id}`)
      .then((response) => response.json())
      .then((data) => setStaffMember(data))
      .catch((error) => console.error('Error fetching staff details:', error));
  }, [id]);

  if (!staffMember) return <p>Loading...</p>;

  return (
    <div>
      <h2>{staffMember.name}</h2>
      <p>Email: {staffMember.email}</p>
      <p>Role: {staffMember.role}</p>
      {/* Add more details as needed */}
    </div>
  );
};

export default StaffDetailPage;


//Run the Application:npm start
 http://localhost:3000
